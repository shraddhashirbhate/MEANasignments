import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'my project';

  myPost = "hello World";
  counter = 100;
  comment = "Hello Comment!!";
  commentList = [];

  increment() {
    this.counter += 1;
  }

  addComment() {
    this.commentList.push("hello Angular!!");
  }
}
