

*   Easy installation: 
    *   ng new project_name --skip-installation
    *   After that go to terminal and type : 
        *   npm install
        *   npm start

*   ng build : this comand is compileing 
    ---------  our program and 
               building our program.
    *   this command will build a dist folder.

*   browser only understand HTML, CSS and JS.


FONT AWESOME MODULE
--------------------
*   npm install @fortawesome/angular-fontawesome@<version>
*   ng add @fortawesome/angular-fontawesome@0.7

HOW TO USE ITS ICONS
---------------------



    
